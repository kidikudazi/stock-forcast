## About Laravel

Real time farm produce price forecasting system for agricultural sector in urban area