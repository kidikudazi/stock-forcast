<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="author" content="TechyDevs"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title><?php echo e(env('APP_NAME')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="images/favicon.png"/>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-select.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.fancybox.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>"/>
    <style>
        .help-block {
            color: #dd4b39;
        }

        .has-error {
            color: #dd4b39;
        }
        .fieldset {
            /* box-shadow: 3px 4px 5px #ccc; */
            border: 1px solid #ccc;
            padding: 30px;
        }
    </style>
</head>
<body>
    <div class="loader-container">
        <div class="loader-ripple">
            <div></div>
            <div></div>
        </div>
    </div>
    <header class="header-area">
        <div class="main-menu-header py-3">
            <div class="container">
                <div class="main-menu-wrapper bg-transparent rounded-0 p-0">
                    <div class="row align-items-center">
                        <div class="col-lg-2">
                            <a href="<?php echo e(url('/')); ?>" class="main-logo">
                                <h5 class="text-white"><?php echo e(env('APP_NAME')); ?></h5>
                                
                                
                            </a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section id="register-section" class="hero-area hero-area-3 bg-dark" style="background-image: url(<?php echo e(asset('assets/admin/img/crops/farm_land.jpg')); ?>);">
        <span class="ring-shape ring-shape-white ring-shape-1 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-2 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-3 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-4 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-5 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-6 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-7 position-absolute"></span>
        <span class="ring-shape ring-shape-white ring-shape-8 position-absolute"></span>
        <div class="container">
            <div class="hero-content">
                <h1 class="sec-title font-size-50 mb-3 text-white  text-center">Real time farm produce forecast</h1>
                <p class="sec-desc text-white  text-center">Easiest way to stay updated with the acurate market price of farm produce</p>
                <?php if(Session::has('error')): ?>
                    <div class="col-lg-6 mx-auto mt-5">
                        <div class="alert alert-danger">
                            <span><?php echo e(session('error')); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="col-lg-6 mx-auto mt-5">
                        <div class="alert alert-success">
                            <span><?php echo e(session('success')); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                <div id="login-container" style="background: black;">
                    <form class="padding-top-35px col-lg-6 mx-auto" method="POST" id="login-form" action="<?php echo e(route('login')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <fieldset class="fieldset">
                            <legend>Login</legend>
                            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" class="form-control form--control" placeholder="Enter your email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('email')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control form--control" placeholder="Enter your password" value="<?php echo e(old('password')); ?>">
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm float-right">Login</button>
                            </div>
                            <br><br>
                            <a href="#register-container" id="register-link">Don't have an account, register Now!</a>
                        </fieldset>
                    </form>
                </div>

                <div id="register-container" style="background: black;">
                    <form class="padding-top-35px col-lg-6 mx-auto" method="POST" id="register-form" action="<?php echo e(route('register')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <fieldset class="fieldset">
                            <legend>Register</legend>
                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <label for="name">Fullname</label>
                                <input type="text" name="name" id="name" class="form-control form--control" placeholder="Enter your fullname" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block mt-0 mr-50"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" class="form-control form--control" placeholder="Enter your email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('email')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                                <label for="phone">Phone</label>
                                <input type="number" name="phone" id="phone" required class="form-control form--control" placeholder="Enter your phone" value="<?php echo e(old('phone')); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('phone')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="register-password" class="form-control form--control" placeholder="Enter your password" value="<?php echo e(old('password')); ?>">
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
                                <label for="confirm_password">Confirm Password</label>
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control form--control" placeholder="Retype your password" value="<?php echo e(old('confirm_password')); ?>">
                                <?php if($errors->has('confirm_password')): ?>
                                    <span class="help-block mt-0 mr-50">
                                        <?php echo e($errors->first('confirm_password')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm float-right">Register</button>
                            </div>

                            <br><br>
                            <a href="#login-container" id="login-link">Already registered, login now!</a>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
        <svg class="hero-svg hero--svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z"></path>
        </svg>
    </section>
    

    

    <section class="footer-area padding-top-80px pb-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item mb-5">
                        <a href="/" class="d-block">
                            <h5><?php echo e(env('APP_NAME')); ?></h5>
                        </a>
                        <ul class="list-items pt-4">
                            <li class="mb-3"><a href="mailto:example@gmail.com"><i class="fal fa-envelope mr-1 font-size-14"></i> example@gmail.com</a></li>
                            <li class="mb-3"><a href="tel:0021621184010"><i class="fal fa-phone mr-1 font-size-14"></i> 00216 21 184 010</a></li>
                            <li class="mb-3"><i class="fal fa-map-marker-alt mr-1 font-size-14"></i> Ilorin, Kwara State</li>

                        </ul>
                        <div class="social-icons">
                            <a href="#" class="icon-element icon-element-sm mr-1"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="icon-element icon-element-sm mr-1"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="icon-element icon-element-sm mr-1"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#" class="icon-element icon-element-sm mr-1"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div><!-- end footer-item -->
                </div><!-- end col-lg-3 -->
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item mb-5">
                        <h5 class="mb-3 font-weight-semi-bold">Product Forecast</h5>
                        <div class="title-shape border-bottom-0"><span></span></div>
                        </div><!-- end footer-item -->
                </div><!-- end col-lg-3 -->
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item mb-5">
                        <h5 class="mb-3 font-weight-semi-bold">Help & Support</h5>
                        <div class="title-shape border-bottom-0"><span></span></div>
                    </div><!-- end footer-item -->
                </div><!-- end col-lg-3 -->
                <div class="col-lg-3 col-md-6">
                    <div class="footer-item mb-5">
                        <h5 class="mb-3 font-weight-semi-bold">Subscribe to Newsletter</h5>
                        <div class="title-shape border-bottom-0"><span></span></div>
                        <p class="pt-4">Get farm produce analysis, news and updates right to your inbox!</p>
                        <form action="#" class="pt-3">
                            <input type="text" class="form-control form--control mb-3" placeholder="Enter email address">
                            <button class="btn btn-primary w-100" type="submit">Subscribe Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <hr class="border-top-gray my-4">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-between">
                <p class="copy-desc">Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e(env('APP_NAME')); ?>. All Rights Reserved.</p>
            </div>
        </div>
    </section>
    <div id="scroll-to-top">
        <i class="far fa-angle-up" title="Go top"></i>
    </div>
    <script src="<?php echo e(asset('assets/js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.lazy.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
    <script>
        // window.setInterval(() => {
        //     window.location.reload();
        // }, 60000);

        $(document).ready(function () {
            document.querySelector('#register-container').style.display = 'none';
        });

        $('#login-link').on('click', () => {
            $('#login-container').fadeIn();
            $('#register-container').hide(300);
        });

        $('#register-link').on('click', () => {
            $('#register-container').fadeIn();
            $('#login-container').hide(300);
        });

        $('#register-form').validate({
            rules: {
                name: { required: true },
                email: { required: true, email:  true },
                phone: { required: true, minlength: 11, maxlength: 11 },
                password: { required: true },
                confirm_password: { required: true, equalTo: '#register-password' }
            },
            messages: {
                name: { required: 'The Name field is required.' },
                email: { required: 'The Email field is required.' },
                phone: { required: 'The Phone field is required.' },
                password: { required: 'The Password field is required.' },
                confirm_password: { 
                    required: 'The Confirm Password field is required.',
                    equalTo: 'Passwords does not match'
                }
            },
            onfocus: true,
            onblur: true,
            errorElement: 'strong',
            errorClass: 'help-block',
            highlight: function (element) { 
                $(element).closest('.form-group').addClass('has-error');
            },
            unhighlight: function (element) {
                $(element).closest('.form-group').removeClass('has-error');
            },
            errorPlacement: function (error, element) {
                if(element.parent('.input-group').length) {
                    error.insertAfter(element.parent());
                    return false;
                } else {
                    error.insertAfter(element);
                    return false;
                }
            }
        });

        $('#login-form').validate({
            rules: {
                email: { required: true, email: true },
                password: { required: true }
            },
            messages: {
                email: { required: 'The Email field is required.' },
                password: { required: 'The Password field is required.' }
            },
            onfocus: true,
            onblur: true,
            errorElement: 'strong',
            errorClass: 'help-block',
            highlight: function (element) { 
                $(element).closest('.form-group').addClass('has-error');
            },
            unhighlight: function (element) {
                $(element).closest('.form-group').removeClass('has-error');
            },
            errorPlacement: function (error, element) {
                if(element.parent('.input-group').length) {
                    error.insertAfter(element.parent());
                    return false;
                } else {
                    error.insertAfter(element);
                    return false;
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\projects\laravel\stock-forcast\resources\views/index.blade.php ENDPATH**/ ?>