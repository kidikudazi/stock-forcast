<footer class="footer">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-left">
            <p>&copy; Copyright <?php echo e(date('Y')); ?>. All rights reserved.</p>
        </div>
        <div class="col  col-sm-6 ml-sm-auto text-center text-sm-right">
            <p><?php echo e(env('APP_NAME')); ?> Limited</p>
        </div>
    </div>
</footer><?php /**PATH C:\projects\laravel\produce-forecast\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>