<link rel="shortcut icon" href="<?php echo e(asset('pigisty-logo.png')); ?>">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/vendors.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/style.css')); ?>" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<style>
    .help-block {
        color: #dd4b39;
    }

    .has-error {
        color: #dd4b39;
    }
</style><?php /**PATH C:\projects\laravel\stock-forcast\resources\views/layouts/admin/styles.blade.php ENDPATH**/ ?>