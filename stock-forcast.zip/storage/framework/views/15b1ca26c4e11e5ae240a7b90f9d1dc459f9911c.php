<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(env('APP_NAME')); ?> | Farm Stocks </title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <?php echo $__env->make('layouts.user.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="app">
        <div class="app-wrap">
            <?php echo $__env->make('layouts.user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="app-container">
                <?php echo $__env->make('layouts.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="app-main" id="main">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form method="GET" action="<?php echo e(route('user.stock.search')); ?>" id="filter-form" novalidate>
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="search">Select Option</label>
                                                <select name="search" id="search" class="form-control">
                                                    <option value="">--Select Option--</option>
                                                    <option value="oldest">Updated last 7 days</option>
                                                    <option value="latest">Newly added in last 7 days</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-sm float-right">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="card datatable-wrapper table-responsive">
                                <table id="list" class="display compact table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Produce</th>
                                        <th scope="col">Previous Price</th>
                                        <th scope="col">Current Price</th>
                                        <th scope="col">Unit</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $farm_stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $prevGainOrLoss  =  floatval($stock->current_price) - floatval($stock->previous_price);
                                            ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?>.</th>
                                                <td class="d-flex align-items-center crypto-name-wrap">
                                                    <p class="line-height-18">
                                                        <?php echo e($stock->name); ?>

                                                    </p>
                                                </td>
                                                <td><span class="text-danger">&#8358;<?php echo e(number_format($stock->previous_price, 2)); ?></span>
                                                </td>
                                                <td>
                                                    <span class="text-success">&#8358;<?php echo e(number_format($stock->current_price, 2)); ?></span> 
                                                    <?php if($prevGainOrLoss < 1): ?>
                                                        <span class="fa fa-long-arrow-down text-danger" style="font-weight: bold;"></span>
                                                    <?php else: ?>
                                                        <span class="fa fa-long-arrow-up text-success" style="font-weight: bold;"></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($stock->unit); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-12">
                                <hr>
                                <div class="text-center">
                                    <?php echo e($farm_stocks->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('layouts.user.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        (function ($) {
            $("#filter-form").validate({
                rules: {
                    search: { required: true }
                },
                messages: {
                    search: { required: "This field is required." }
                },
                errorClass: "help-block",
                errorElement: "strong",
                onfocus:true,
                onblur:true,
                highlight:function(element){
                    $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
                },
                unhighlight:function(element){
                    $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
                },
                errorPlacement:function(error, element){
                    if(element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                        return false;
                    } else {
                        error.insertAfter(element);
                        return false;
                    }
                },
            });
        })(jQuery);
    </script>
</body>
</html><?php /**PATH C:\projects\laravel\stock-forcast\resources\views/user/stocks.blade.php ENDPATH**/ ?>