<aside class="app-navbar">
    <div class="sidebar-nav scrollbar scroll_light">
        <ul class="metismenu" id="sidebarNav">
            <li class="nav-static-title">Dashboard</li>
            <li class="active">
                <a href="<?php echo e(url('administrator/home')); ?>" aria-expanded="false">
                    <i class="nav-icon ti ti-rocket"></i><span class="nav-title">Home</span>
                </a>
            </li>                       
            <li>
                <a href="<?php echo e(url('administrator/stock')); ?>" aria-expanded="false">
                    <i class="nav-icon fa fa-list"></i><span class="nav-title">Stock</span>
                </a>
            </li>
        </ul>
    </div>
</aside><?php /**PATH C:\projects\laravel\stock-forcast\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>