<aside class="app-navbar">
    <div class="sidebar-nav scrollbar scroll_light">
        <ul class="metismenu" id="sidebarNav">
            <li class="nav-static-title">Dashboard</li>
            <li class="active">
                <a href="{{ url('administrator/home') }}" aria-expanded="false">
                    <i class="nav-icon ti ti-rocket"></i><span class="nav-title">Home</span>
                </a>
            </li>                       
            <li>
                <a href="{{ url('administrator/stock') }}" aria-expanded="false">
                    <i class="nav-icon fa fa-list"></i><span class="nav-title">Stock</span>
                </a>
            </li>
        </ul>
    </div>
</aside>