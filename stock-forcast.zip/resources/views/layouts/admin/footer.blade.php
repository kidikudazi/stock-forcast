<footer class="footer">
    <div class="row">
        <div class="col-12 col-sm-6 text-center text-sm-left">
            <p>&copy; Copyright {{ date('Y') }}. All rights reserved.</p>
        </div>
        <div class="col  col-sm-6 ml-sm-auto text-center text-sm-right">
            <p>{{ env('APP_NAME') }} Limited</p>
        </div>
    </div>
</footer>