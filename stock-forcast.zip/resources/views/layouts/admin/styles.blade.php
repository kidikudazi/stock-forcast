<link rel="shortcut icon" href="{{ asset('pigisty-logo.png') }}">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{ asset('assets/admin/css/vendors.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('assets/admin/css/style.css') }}" />
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
    .help-block {
        color: #dd4b39;
    }

    .has-error {
        color: #dd4b39;
    }
</style>